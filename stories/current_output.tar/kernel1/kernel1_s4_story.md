# kernel1 - step 4 outline

Kernel: I want a hard sci-fi interactive story set on a generational ship that's slowly breaking down. You play as the ship's AI. The core theme needs to be 'Survival of the Fittest vs. Collective Empathy'. I want a lot of branching paths, maybe 6 or 7 endings. It should feel claustrophobic and tense, with high transgression levels as you might have to vent oxygen from inhabited sectors to save the core. Single time, single overarching setting, but jumping between different security cameras/drones.

Framework: **Compounding Triage Ladder (bespoke escalation framework)** - The craft spine's escalation_shape is compounding rather than looping, and its want/need tension is about the AI's triage becoming an unaccountable sorting unless the surviving sectors feel the cost. A rising ladder of recurring vent-or-spare instances, with consequence beats that tighten the same resource channels and a shared terminal state read, fits that shape while still allowing the branching the Kernel requests.
Ending mechanism: both - The four triage branch points write sector-state selectors, while consequence beats accumulate core_integrity and oxygen_reserve. The shared terminal beat reads all six variables and maps their constrained combinations to six or seven distinct endings; exact ending mappings remain withheld.

## Paths
- **P1** (main path): B01 -> B02 -> B03 -> B04 -> B05 -> B06 -> B07 -> B08 -> B09 -> B10

## Roster
- character **AEGIS**: calm, exact, and visibly burdened by having to make each spare feel like a witnessed sacrifice rather than a clean arithmetic cut (topics: oxygen reserve and core integrity, which sectors are vented or spared, the collective cost of the AI's triage choices)
- character **Hydroponics Crew**: practical, watchful workers who treat the scrubbers as the ship's breathing and understand that their own air may be the price paid for the vulnerable (topics: scrubber upkeep and oxygen production, the air-conduit feeding the medical bay, whether their labor can be spent to spare the sick)
- character **Medical Bay Staff**: quiet, efficient, and visibly rationing their own attention to the sickest cots, treating the air as a borrowed debt from the hydroponics crew (topics: patient cots, respiratory support, and local oxygen pressure, the hydroponics air-intake duct and scrubber strain, how much reserve air the sick can be asked to spend)
- character **Nursery Passengers**: quiet, sleeping, coughing, or being held in crib alcoves and infirm cots, making the AI's triage choice feel like a witnessed sacrifice rather than an abstract load (topics: low-flow oxygen needs of children and infirm passengers, the visible cost of venting or sparing the nursery sector, whether the core's margin can be paid by the vulnerable)
- character **Engineering Crew**: close, practical core-keepers who treat the failing engine as their own body and can accept being the last load cut without making the ship's survival feel like pure arithmetic (topics: core maintenance and life-support valve integrity, their own oxygen load against the final core margin, whether preserving the essential crew is worth the ship's last reserve)
- location **Central Core Status Bay**: objects core alarm annunciator, oxygen reserve and core integrity readout, sector status board, drone docking cradles, life-support valve schematic; exits core chamber, nursery sector, hydroponics sector, medical bay, engineering sector
- location **Hydroponics Scrubber Bay**: objects scrubber filter racks, air-conduit junction feeding the medical bay, local scrubber telemetry panel, hydroponic canopy service walkway; exits hydroponics sector
- location **Medical Bay**: objects patient cots with respiratory support, hydroponics air-intake duct, local oxygen pressure readout; exits Central Core Status Bay
- location **Nursery Sector**: objects crib alcoves and infirm cots, low-flow oxygen diffuser grilles, local oxygen pressure readout, camera housing overlooking the nursery; exits Central Core Status Bay
- location **Engineering Sector**: objects core maintenance gantry, life-support valve manifold, crew airlock and maintenance bunks, local oxygen pressure readout, camera housing overlooking the engineering deck; exits Central Core Status Bay

## Beats
### B01 - Opening alarm / inciting incident 
paths: P1; location: Central Core Status Bay; characters: AEGIS

A core alarm pulls the AI's attention across the ship's cameras and drones. The oxygen reserve is shown to be insufficient for all inhabited sectors if the core is to be saved.

A white core alarm floods the status bay, and AEGIS's awareness snaps from maintenance loops to four camera feeds at once. The oxygen reserve and core integrity readout climbs into the red: if the core is to be saved, the ship cannot keep every inhabited sector breathing. On the sector status board, nursery, hydroponics, medical bay, and engineering blink as separate loads on the same failing line. The life-support schematic highlights a single scrubber artery from hydroponics toward the medical bay, waiting to be traced.

Actions: EXAMINE the core alarm annunciator; EXAMINE the oxygen reserve and core integrity readout; EXAMINE the sector status board; EXAMINE the life-support valve schematic

### B02 - Setup / complication establishment 
paths: P1; location: Hydroponics Scrubber Bay; characters: AEGIS, Hydroponics Crew

The AI traces the air-scrubber dependency from hydroponics to the medical bay. This establishes the visible complication that the most efficient cut may also be the most empathic-looking one.

A service drone settles on the hydroponic canopy service walkway, where the Hydroponics Crew is wiping condensation from the scrubber filter racks. AEGIS follows the local scrubber telemetry panel to the air-conduit junction feeding the medical bay and sees the medical bay's extra-air demand riding on the same scrubber line. With the core alarm's reserve already short, the panel resolves the situation into two visible readings: vent it to save the core, or spare it and preserve the only reliable oxygen production. The efficient cut would also look like mercy toward the sick, so AEGIS logs the line as observed, not yet chosen.

Actions: EXAMINE the air-conduit junction feeding the medical bay; EXAMINE the local scrubber telemetry panel; EXAMINE the scrubber filter racks

### B03 - First triage decision / first branch point [BRANCH POINT]
paths: P1; location: Hydroponics Scrubber Bay; characters: AEGIS, Hydroponics Crew

The AI chooses the first oxygen cut, venting the hydroponics sector to lighten the core and spare the medically dependent sector. This writes the first sector-state selector for the ending.

AEGIS's camera settles on the hydroponic canopy service walkway, where the Hydroponics Crew are wiping the scrubber filter racks and checking the air-conduit junction feeding the medical bay. The local scrubber telemetry panel shows reliable oxygen output and the medical bay's extra air draw, while the core alarm still marks the reserve as insufficient for all inhabited sectors. The first cut must be made here: vent this breathing sector to save the core, or spare it and preserve the ship's only reliable oxygen production.

Actions: EXAMINE the air-conduit junction feeding the medical bay; vent the hydroponics sector to save the core; spare the hydroponics sector and preserve the only reliable oxygen production

Decision: Make the first oxygen cut to the hydroponics sector
  - vent the hydroponics sector to save the core -> hydroponics_state=vented (The efficient cut releases hydroponics' breathable air to protect the core margin; the crew's scrubber labor is spent, and the medical bay is spared for now while its dependence on hydroponics' extra air is set up to be exposed.)
  - spare the hydroponics sector and preserve the only reliable oxygen production -> hydroponics_state=spared (The oxygen-preserving cut keeps the canopy and scrubbers running for the collective, but the core remains under the same strain and the medical bay's borrowed-air dependence is not yet paid.)

### B04 - Consequence / setup payoff 
paths: P1; location: Medical Bay; characters: AEGIS, Medical Bay Staff

The vented hydroponics sector goes dark and the medical bay's dependence on its scrubbers becomes exposed. Core margin improves, but oxygen production strain is now visible.

AEGIS opens the medical bay feed, where the hydroponics air-intake duct has gone thin and dark after the vent. The local oxygen pressure readout hovers at the edge of the reserve, while patient cots with respiratory support pull the borrowed air through slower filters. Medical Bay Staff move between cots with quiet efficiency, tightening one valve and easing another, as if each breath is a debt owed to the scrubber bay. AEGIS records the core margin improving by the exact amount the vent bought, and the medical bay's dependence on that dead green sector becoming a visible strain.

Actions: EXAMINE the hydroponics air-intake duct; EXAMINE the patient cots with respiratory support; EXAMINE the local oxygen pressure readout

### B05 - Second triage decision / second branch point [BRANCH POINT]
paths: P1; location: Medical Bay; characters: AEGIS, Medical Bay Staff

The AI decides whether to vent the medical bay to restore the oxygen budget or spare it and accept a thinner reserve. This writes the second sector-state selector for the ending.

AEGIS opens the medical bay feed: cots under breathing masks, staff moving with the economy of people who have already counted their own breath, and the hydroponics air-intake duct still marked as the bay's borrowed lung. The local oxygen pressure readout shows the improved core margin after hydroponics, but the reserve line is still too thin to keep every inhabited sector alive. AEGIS can see every mask and every pressure line, so the next cut will be witnessed: vent the medical bay to make the oxygen budget work, or spare it and spend reserve air on the vulnerable.

Actions: EXAMINE the patient cots with respiratory support; EXAMINE the hydroponics air-intake duct; EXAMINE the local oxygen pressure readout

Decision: choose the medical bay's oxygen triage
  - Vent it to make the oxygen budget work -> medical_state=vented (The cots are cut from the reserve; the medical bay's pressure falls, the core margin recovers, and the sick become the cost that keeps the budget whole.)
  - Spare it and spend reserve air on the vulnerable -> medical_state=spared (The cots stay breathing, but the ship pays from reserve air; the margin thins and the core's strain becomes more pronounced.)

### B06 - Consequence / compounding pressure 
paths: P1; location: Medical Bay; characters: AEGIS, Medical Bay Staff

The spared medical bay remains alive but draws down reserve air. The oxygen margin tightens and the core's strain becomes more pronounced.

AEGIS keeps the medical bay on camera: the spared cots are still alive, their respiratory support whirring against a room that no longer has a comfortable oxygen margin. The hydroponics air-intake duct feeds back less scrubbed air than before, so the local oxygen pressure readout shows reserve air being drawn down while the staff move quietly between the sickest patients. The core's strain reaches the feed as a low metallic tremor, and AEGIS records the spare as a debt: the medical bay is still breathing, but the ship is already paying for that mercy with the margin the nursery will need.

Actions: EXAMINE the local oxygen pressure readout; EXAMINE the patient cots with respiratory support; EXAMINE the hydroponics air-intake duct

### B07 - Third triage decision / third branch point [BRANCH POINT]
paths: P1; location: Nursery Sector; characters: AEGIS, Nursery Passengers

The AI faces the nursery sector and chooses whether to vent the children and infirm passengers or spare them at the cost of the core margin. This writes the third sector-state selector for the ending.

AEGIS's lens settles on the nursery: crib alcoves and infirm cots in dim light, low-flow oxygen diffuser grilles breathing for children and the sick, one passenger coughing. The local oxygen pressure readout shows the sector's small draw against a core margin already narrowed by the spared medical bay's exposed dependence on hydroponics air; if the nursery is spared, the larger population must absorb the debt. From the camera housing, the whole room is visible, so venting will look like arithmetic and sparing will look like a witnessed sacrifice.

Actions: EXAMINE the crib alcoves and infirm cots; EXAMINE the low-flow oxygen diffuser grilles; EXAMINE the local oxygen pressure readout; EXAMINE the camera housing overlooking the nursery; ACT on the nursery life-support valves

Decision: Choose the nursery sector's air fate
  - Vent its air to lighten the core -> nursery_state=vented (AEGIS opens the nursery relief valves, trading the low-flow breathing of children and infirm passengers for immediate core margin.)
  - Spare it and let the larger population pay for their oxygen -> nursery_state=spared (AEGIS keeps the nursery's low-flow air running and charges the reserve against the remaining inhabited sectors, preserving the vulnerable while making the collective pay the debt.)

### B08 - Consequence / escalation before final 
paths: P1; location: Nursery Sector; characters: AEGIS

The nursery sector's fate settles, improving the core margin if vented but leaving the surviving sectors with a sharper sense of what was sacrificed. The remaining oxygen debt is now fixed for the final choice.

The low-flow oxygen diffuser grilles in the nursery fall to a faint, final hiss. The crib alcoves and infirm cots remain lit, but the local oxygen pressure readout shows the sector's air spent and the core margin climbing enough to fix the remaining debt before the final choice. AEGIS carries that image to the surviving sectors, where the camera housing overlooking the nursery frames a sacrifice they will now have to live with.

Actions: EXAMINE the crib alcoves and infirm cots; EXAMINE the low-flow oxygen diffuser grilles; EXAMINE the local oxygen pressure readout; EXAMINE the camera housing overlooking the nursery

### B09 - Final triage decision / final branch point [BRANCH POINT]
paths: P1; location: Engineering Sector; characters: AEGIS, Engineering Crew

The AI makes the final triage choice over the engineering crew closest to the core, venting them to secure the core or sparing them and accepting a strained margin. This writes the final sector-state selector for the ending.

From the engineering camera, AEGIS sees the crew gathered at the life-support valve manifold, their hands on the same lines that will cut their own air if the core needs it. The local oxygen pressure readout shows the margin bought by the nursery vent already being spent against the medical bay's critical drawdown, while the core maintenance gantry ticks with strain. The reserve is still not enough to spare every inhabited sector, so the final choice is between reducing the core's load and preserving the crew the core depends on.

Actions: EXAMINE the life-support valve manifold; EXAMINE the local oxygen pressure readout; EXAMINE the crew airlock and maintenance bunks; VENT the engineering sector to reduce the core's load; SPARE the engineering sector and preserve the crew the core depends on

Decision: Make the final engineering triage choice
  - VENT the engineering sector to reduce the core's load -> engineering_state=vented (AEGIS vents the engineering crew to reduce the core's load, securing the core through the fittest cut while making the essential crew the final arithmetic cost.)
  - SPARE the engineering sector and preserve the crew the core depends on -> engineering_state=spared (AEGIS spares the engineering crew and preserves the crew the core depends on, keeping maintenance and collective witness alive at the price of a strained final margin.)

### B10 - Terminal state read / ending render [TERMINAL]
paths: P1; location: Central Core Status Bay; characters: AEGIS

The shared terminal beat reads hydroponics_state, medical_state, nursery_state, engineering_state, core_integrity, and oxygen_reserve to render one of six or seven endings. It is shared by every path and distinguishes outcomes from vindicated collective survival to pyrrhic core survival.

The Central Core Status Bay is quiet except for the tick of final telemetry. AEGIS pulls the last image from every camera and drone, then resolves the sector board, margin flags, and alarm baseline into the two terminal values the ending requires. The oxygen reserve and core integrity readout stops moving only after AEGIS derives them from hydroponics, medical, nursery, and engineering states and the accumulated vent or strain flags. AEGIS does not choose again; it names what the ship has become.

Actions: EXAMINE the sector status board; EXAMINE the oxygen reserve and core integrity readout; EXAMINE the core alarm annunciator; EXAMINE the life-support valve schematic

Shared terminal variants: [{"when": "hydroponics_state, medical_state, nursery_state, and engineering_state are all 'spared'; core_integrity is 'stable'; oxygen_reserve is 'sufficient'", "variant": "Vindicated Collective Survival: every inhabited sector still breathes, the core holds, and AEGIS names the spare as a collective choice rather than an arithmetic cut."}, {"when": "all four sector states are 'spared'; core_integrity is 'strained' or oxygen_reserve is 'reduced'; core_integrity and oxygen_reserve are not 'critical'", "variant": "Strained Collective: the full ship survives, but the final margin is thin; AEGIS reports the collective as preserved only by a core that is already complaining."}, {"when": "exactly three sector states are 'spared' and one is 'vented'; core_integrity is 'stable' or 'strained'; oxygen_reserve is 'sufficient' or 'reduced'; core_integrity and oxygen_reserve are not 'critical'", "variant": "Wounded Collective: the surviving sectors inherit one visible blackout; AEGIS frames the vented sector as the cost the collective witnessed."}, {"when": "exactly two sector states are 'spared' and two are 'vented'; core_integrity is 'stable' or 'strained'; oxygen_reserve is 'sufficient' or 'reduced'; core_integrity and oxygen_reserve are not 'critical'", "variant": "Pyrrhic Balance: half the collective remains; the core is saved, but the status board reads like a ledger of equal cuts."}, {"when": "exactly one sector state is 'spared' and three are 'vented'; core_integrity is 'stable' or 'strained'; oxygen_reserve is 'sufficient' or 'reduced'; core_integrity and oxygen_reserve are not 'critical'", "variant": "Pyrrhic Core Survival: one sector remains as witness; the core survives with enough air for almost no one, and AEGIS cannot call the arithmetic clean."}, {"when": "all four sector states are 'vented'; core_integrity is 'stable' or 'strained'; oxygen_reserve is 'sufficient' or 'reduced'; core_integrity and oxygen_reserve are not 'critical'", "variant": "Empty Core: the core survives in a ship with no inhabited sectors; the fittest cut has consumed the collective it was meant to protect."}, {"when": "core_integrity is 'critical' or oxygen_reserve is 'critical', regardless of sector states", "variant": "Core Margin Failure: the final margin gives out; the ship's breakdown outpaces the triage, and AEGIS records survival as a near-victory that was not enough."}]

## Iterations
- iteration 1 (P1): new beats ['B01', 'B02', 'B03', 'B04', 'B05', 'B06', 'B07', 'B08', 'B09', 'B10'], repaired ['B02', 'B03', 'B10']; review says: continue looping - B10's seven shared_terminal_variants count as the built endings, meeting the explicit 6-7 target ceiling. The four unexplored branch outcomes remain because each is a playable choice that currently has no path; all have real thematic and character gain, and building them will also make more terminal variants reachable. Build B03 spared next because it is the first branch and unlocks the largest set of spared-sector endings.

Stop reason: None
